# Trytet Python SDK

Official Python client for the [Trytet Engine](https://trytet.io) — a sub-millisecond, hyper-ephemeral Wasm execution substrate for AI agents.

## Installation

```bash
pip install trytet-client
```

## Quick Start

```python
import asyncio
from trytet_client import TrytetClient, TetExecutionRequest

async def main():
    async with TrytetClient(base_url="http://localhost:3000") as client:
        # Execute a Wasm payload
        with open("my_agent.wasm", "rb") as f:
            payload = list(f.read())

        result = await client.execute(TetExecutionRequest(
            payload=payload,
            allocated_fuel=1_000_000,
            alias="my-agent",
        ))
        print(f"Status: {result.status}")
        print(f"Fuel consumed: {result.fuel_consumed}")

        # List available MCP tools
        tools = await client.list_tools()
        for tool in tools:
            print(f"  {tool.name}: {tool.description}")

        # Invoke a cartridge
        from trytet_client import CartridgeInvocation
        cart_result = await client.invoke_cartridge(CartridgeInvocation(
            component_id="js-evaluator",
            payload="2 + 2",
            fuel=1_000_000,
        ))
        print(cart_result.output)

asyncio.run(main())
```

## Features

- Full async HTTP client with retry and backoff
- MCP (Model Context Protocol) support — tools, resources, prompts
- Cartridge management API
- WebSocket telemetry streaming
- Pydantic models for all API types
- Type-safe request/response handling
